#include <Arduino_GFX_Library.h>
#include <Wire.h>
#include "touch.h"

#define I2C_SDA_PIN 17
#define I2C_SCL_PIN 18
#define TOUCH_RST -1 // 38
#define TOUCH_IRQ -1 // 0

#define TFT_BL 38
#define BUTTON_PIN 14
#define ENCODER_CLK 13 // CLK
#define ENCODER_DT 10  // DT

int counter = 0;
int State;
int old_State;

int move_flag = 0;
int button_flag = 0;
int flesh_flag = 1;

int x = 0, y = 0;

#define COLOR_NUM 5
int ColorArray[COLOR_NUM] = {WHITE, BLUE, GREEN, RED, YELLOW};

// #define COLOR_NUM 18
// int ColorArray[18] = {BLUE, GREEN, WHITE, RED, ORANGE, NAVY, DARKGREEN, DARKCYAN, MAROON, PURPLE, OLIVE, LIGHTGREY, DARKCYAN, DARKGREY, MAGENTA, YELLOW, GREENYELLOW, PINK};

Arduino_DataBus *bus = new Arduino_SWSPI(
    GFX_NOT_DEFINED /* DC */, 1 /* CS */,
    46 /* SCK */, 0 /* MOSI */, GFX_NOT_DEFINED /* MISO */);

Arduino_ESP32RGBPanel *rgbpanel = new Arduino_ESP32RGBPanel(
    2 /* DE */, 42/* VSYNC */, 3 /* HSYNC */, 45 /* PCLK */,
    4 /* R0 */, 41 /* R1 */, 5 /* R2 */, 40 /* R3 */, 6 /* R4 */,
    39 /* G0/P22 */, 7 /* G1/P23 */, 47 /* G2/P24 */, 8 /* G3/P25 */, 48 /* G4/P26 */, 9 /* G5 */,
    11 /* B0 */, 15 /* B1 */, 12 /* B2 */, 16 /* B3 */, 21 /* B4 */,
    1 /* hsync_polarity */, 10 /* hsync_front_porch */, 8 /* hsync_pulse_width */, 50 /* hsync_back_porch */,
    1 /* vsync_polarity */, 10 /* vsync_front_porch */, 8 /* vsync_pulse_width */, 20 /* vsync_back_porch */);


Arduino_RGB_Display *gfx = new Arduino_RGB_Display(
    480 /* width */, 480 /* height */, rgbpanel, 0 /* rotation */, true /* auto_flush */,
    bus, GFX_NOT_DEFINED /* RST */, st7701_type5_init_operations, sizeof(st7701_type5_init_operations));


void encoder_irq()
{
  State = digitalRead(ENCODER_CLK);
  if (State != old_State)
  {
    if (digitalRead(ENCODER_DT) == State)
    {
      counter++;
    }
    else
    {
      counter--;
    }
  }
  old_State = State; // the first position was changed
  move_flag = 1;
}

void pin_init()
{
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, HIGH);

  pinMode(ENCODER_CLK, INPUT_PULLUP);
  pinMode(ENCODER_DT, INPUT_PULLUP);
  old_State = digitalRead(ENCODER_CLK);

  attachInterrupt(ENCODER_CLK, encoder_irq, CHANGE);
}

void page_1()
{
  String temp = "";
  gfx->fillScreen(ColorArray[((unsigned)counter / 2 % COLOR_NUM)]);
  gfx->setTextSize(4);
  gfx->setTextColor(BLACK);
  gfx->setCursor(120, 100);
  gfx->println(F("Makerfabs"));

  gfx->setTextSize(3);
  gfx->setCursor(30, 160);
  gfx->println(F("2.1inch TFT with Touch "));

  gfx->setTextSize(4);
  gfx->setCursor(60, 200);
  temp = temp + "Encoder: " + counter;
  gfx->println(temp);

  gfx->setTextSize(4);
  gfx->setCursor(60, 240);
  temp = "";
  temp = temp + "BUTTON: " + button_flag;
  gfx->println(temp);

  gfx->setTextSize(4);
  gfx->setCursor(60, 280);
  temp = "";
  temp = temp + "Touch X: " + x;
  gfx->println(temp);

  gfx->setTextSize(4);
  gfx->setCursor(60, 320);
  temp = "";
  temp = temp + "Touch Y: " + y;
  gfx->println(temp);

  // gfx->fillRect(240, 400, 30, 30, ColorArray[(((unsigned)counter / 2 + 1) % COLOR_NUM)]);

  flesh_flag = 0;
}

void setup()
{
  USBSerial.begin(115200);

  pin_init();

  delay(1000);
  USBSerial.println("Test V1.1");
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);

  // Init Display
  gfx->begin();
}

void loop()
{

  if (read_touch(&x, &y) == 1)
  {
    USBSerial.print("Touch ");
    USBSerial.print(x);
    USBSerial.print("\t");
    USBSerial.println(y);

    flesh_flag = 1;
  }
  if (digitalRead(BUTTON_PIN) == 0)
  {
    if (button_flag != 1)
    {
      button_flag = 1;
      flesh_flag = 1;
    }

    USBSerial.println("Button Press");
  }
  else
  {
    if (button_flag != 0)
    {
      button_flag = 0;
      flesh_flag = 1;
    }
  }

  if (move_flag == 1)
  {
    USBSerial.print("Position: ");
    USBSerial.println(counter);
    move_flag = 0;
    flesh_flag = 1;
  }
  if (flesh_flag == 1)
    page_1();

  delay(100);
}
